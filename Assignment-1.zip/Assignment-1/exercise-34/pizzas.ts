const pizza = ['fajita','cheese','Tikka',];
for (let i = 0; i < pizza.length; i++)
{   
    console.log( 'I like '+pizza[i] + ' pizza.');
}
console.log('Pizza is a dish of Italian origin consisting of a usually round,flat.');
console.log('Base of leavened wheat-based dough topped with tomatoes, cheese, and often various other ingredients.');
console.log('I really love pizza'); 
