var fav_fruits = ['Orange', 'Mango', 'Cherry'];
if ('Orange' in fav_fruits) {
    console.log(fav_fruits);
    //console.log('My fav fruit is '+ fav_fruits[0] );
}
