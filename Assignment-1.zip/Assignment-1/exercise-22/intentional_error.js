var arr = ["Hira", "Rida", "Aishah", "Faiza"];
console.log(arr);
//add person name in the middle of an array
var temp = arr[2];
console.log(temp);
