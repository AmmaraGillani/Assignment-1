const mountains=['Denali','Mount Elbrus'];
const rivers=['Beas ','Bhima River'];
const countries=['USA','UK'];
const cities=['Paris','Islamabad'];
const languages=['English','Persian'];
