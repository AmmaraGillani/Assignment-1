var mountains = ['Denali', 'Mount Elbrus'];
var rivers = ['Beas ', 'Bhima River'];
var countries = ['USA', 'UK'];
var cities = ['Paris', 'Islamabad'];
var languages = ['English', 'Persian'];
