/*
    Syeda Ammara Afzal
    14 Feb,2023
    The code is operate different calcualtions in display statement and show result is 8. 
*/
console.log((5+3));
console.log((14-6));
console.log(2*4);
console.log(16/2);