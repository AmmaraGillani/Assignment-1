function city_country(city, country) {
    String(city + "," + country);
    //console.log('"' + city+','+country+'"');
    return String;
}
city_country('Islamabad', 'Pakistan');
