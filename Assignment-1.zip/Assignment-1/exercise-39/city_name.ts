function city_country(city,country)
{
    return `"${city},${country}"`;
}
console.log(city_country('Islamabad','Pakistan'));
console.log(city_country('Paris','France'));
console.log(city_country('London','England'));
console.log(city_country('Newyork','America'));