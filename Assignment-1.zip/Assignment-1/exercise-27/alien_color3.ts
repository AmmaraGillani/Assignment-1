var alien_color = 
{
    color1: "green",
    color2: "yellow",
    color3: "red"
};
if (alien_color.color1 == 'green')
{
    console.log('the color is green so Player got 5 points');
}
 else if (alien_color.color2 == 'yellow')
{
    console.log('Player got 10 points');
}
else if (alien_color.color3 == 'red')
{
    console.log('Player got 15 points');
}
if (alien_color.color2 == 'yellow')
{
    console.log('the color is yellow so player got 10 points');
}
if (alien_color.color3 == 'red')
{
    console.log('the color is red so player got 15 points');
}
