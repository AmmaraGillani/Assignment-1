let city = 'Paris';
console.log("Is city == 'Paris'? I predict True.");
console.log(city == 'Paris');

let car = 'Audi';
console.log("Is car == 'Audi '? I predict True.");
console.log(car == 'Audi');

let LED = 'Samsung';
console.log("Is LED == 'Samsung'? I predict True.");
console.log(LED == 'Samsung');

let airLine = 'Turkish';
console.log("Is airLine == 'Turkish'? I predict True.");
console.log(airLine == 'Turkish');

let cruise = 'American Eagle';
console.log("Is cruise == 'American Eagle'? I predict True.");
console.log(cruise == 'American Eagle');

let country = 'NewYork';
console.log("Is country == 'NewYork'? I predict False.");
console.log(country == 'NewYork1');

let mobile = 'MacBook';
console.log("Is Mobile == 'MacBook'? I predict False.");
console.log( mobile != 'MacBook');

let laptop = 'Redmi note 11';
console.log("Is laptop == 'Redmi note 11'? I predict False.");
console.log(laptop != 'Redmi note 11');

let brand = 'whatsapp';
console.log("Is brand == 'whatsapp'? I predict False.");
console.log(brand != 'whatsapp');

let game = 'snapchat';
console.log("Is game == 'snapchat'? I predict False.");
console.log(game != 'snapchat');




