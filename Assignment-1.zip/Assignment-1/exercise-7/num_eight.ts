/*
    Syeda Ammara Afzal
    14 Feb,2023
    In this program different operations are performed and each result of operation is 8. 
*/

let s=2;
let x=4;
let y=8;
let z=16;
console.log('Addition: \n' + '4 + 4 = ' + (x+x) );
console.log('Subtraction: \n' + '16 - 8 = '+ (z-y));
console.log('MultiPlication: \n '+ '2 X 4 = '+ s*x);
console.log('Division: \n' + '16 / 2 = ' + z/s);