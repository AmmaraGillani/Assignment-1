var alien_color = {
    color1: "green",
    color2: "yellow",
    color3: "red"
};
if (alien_color.color1 == 'green') {
    console.log('The player just earned 5 points for shooting the alien.');
}
