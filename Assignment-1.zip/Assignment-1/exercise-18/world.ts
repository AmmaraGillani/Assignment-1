var arr=['Sweden','France', 'England','Germany','America'];
for(let i = 0; i < arr.length; i++)
{
    console.log(arr[i]);
}

// alphabetically order
console.log('Modify in alphabetical Order \n');
arr.sort();
 for(let i = 0; i < arr.length; i++)
 {
        console.log(arr[i]);
 }

 // Reverse alphabetically order
 console.log('Modify in Reverse alphabetical Order \n');
 arr.reverse();
 for(let i = 0; i < arr.length; i++)
 {
        console.log(arr[i]);
 }

 //Reverse the order of list
 console.log('Again Reverse alphabetical Order \n');
 arr.reverse();
 for(let i = 0; i < arr.length; i++)
 {
        console.log(arr[i]);
 }
 //Reverse the order of list again
 console.log('Again Reverse alphabetical Order \n');
 arr.reverse();
 for(let i = 0; i < arr.length; i++)
 {
        console.log(arr[i]);
 }
 // Sort the order of list
 console.log('Modify in Sort alphabetical Order \n');
 arr.sort();
 for(let i = 0; i < arr.length; i++)
 {
        console.log(arr[i]);
 }
 // Sort to change array so it’s stored in reverse alphabetical order
 console.log('Again in Reverse alphabetical Order \n');
 arr.reverse();
 for(let i = 0; i < arr.length; i++)
 {
        console.log(arr[i]);
 }