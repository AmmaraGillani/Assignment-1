var mountains =
{
    first:"Denali",
    second:"Mount Elbrus"
};
var rivers =
{
    first:"Beas",
    second:"Bhima"
};
var countries =
{
    first:"USA",
    second:"UK"
};
var cities =
{
    first:"Paris",
    second:"Newyork"
};
var languages =
{
    first:"English",
    second:"persian"
};