/*
    Syeda Ammara Afzal
    14 Feb,2023
    Hello World
*/
console.log('Hello World');