/*
    Syeda Ammara Afzal
    14 Feb,2023
    The code is store the author name and message in a variable then display the variables. 
*/
var famous_person = "Albert Einstein";
const message = "A person who never made a mistake never tried anything new.";
console.log(famous_person + ' once said ' + ',' + '"' + message +'"' );