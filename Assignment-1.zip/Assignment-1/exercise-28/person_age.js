var person_age = {
    age1: 2,
    age2: 4,
    age3: 13,
    age4: 20,
    age5: 60
};
if (person_age.age1 < 2) {
    console.log('The person is a baby');
}
else if (person_age.age1 <= 4) {
    console.log('The person is toddler');
}
