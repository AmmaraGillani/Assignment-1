function make_shirt(size,text)
{
    console.log('The size of the shirt is '+ size);
    console.log('Text on shirt is '+text);
}
make_shirt(16,'Little green Monster!');