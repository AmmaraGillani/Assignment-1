/*
    Syeda Ammara Afzal
    14 Feb,2023
    show an array with list of statements about transportaion.
 */

var arr =
    [
        "My favorite transport is a four-wheeler car.",
        "I prefer a car to a bike because a car is more comfortable.",
        "I drive my car and kids sit behind me.",
        "We travel to various places with the help of a car.",
        "It enables effortless transportation."
];
    console.log(arr);