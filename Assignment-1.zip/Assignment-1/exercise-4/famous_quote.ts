/*
    Syeda Ammara Afzal
    14 Feb,2023
    The code is store author name and display his quote. 
*/
var author = "Albert Einstein";
console.log(author+ ' once said' + ','+ '“'+ 'A person who never made a mistake never tried anything new.' + '"'); 