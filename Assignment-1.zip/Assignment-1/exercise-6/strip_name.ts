/*
    Syeda Ammara Afzal
    14 Feb,2023
    The code is store the name and display the name in each character with white space (\t) and new line (\n). 
*/
var person_name ="Ammara Afzal";
for (let i=0; i<person_name.length; i++)
{
    console.log(person_name[i] + '\t ');
    console.log('\n');
    
}
console.log(person_name);