/*
    Syeda Ammara Afzal
    14 Feb,2023
    The code is store number in a variable and display the message is my favourite number. 
*/
var fav_num = 7;
const msg= 'My favourite number is ';
console.log(msg + ' ' + fav_num);