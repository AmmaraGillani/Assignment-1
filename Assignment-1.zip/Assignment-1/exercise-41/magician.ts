const magician =['Brown Darren','John Carter','Charles Joseph','John Henry'];
function show_magician(arr=magician)
{

     for (let i = 0; i<arr.length; i++)
     {
            
         console.log(arr[i]);
     }
}
show_magician();