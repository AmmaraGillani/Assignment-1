/*
    Syeda Ammara Afzal
    14 February, 2023
    Store names in array and show array list.
 */
const names = ["Mishal", "Sadaf", "Ayesha", "Ghina", "Hira", "Rida", "Faiza"];
 for (let i = 0; i < names.length ; i ++ ){
     console.log( names[i] );
 }