var peron_name = "Eric";
console.log('"Hello ' + person_name + ',would you like to learn some python today?"');
