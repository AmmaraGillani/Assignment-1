/*
    Syeda Ammara Afzal
    14 Feb,2023
    The code is store name in a variable and display the message. 
*/
var person_name = "Eric";
const string1 = "Hello ";
const string2 = " would you like to learn python today?"
console.log(string1 + person_name+ ","+ string2);